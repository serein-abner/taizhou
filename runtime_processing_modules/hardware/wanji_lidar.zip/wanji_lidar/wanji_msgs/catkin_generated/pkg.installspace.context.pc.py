# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/exbot/catkin_ws/install/include".split(';') if "/home/exbot/catkin_ws/install/include" != "" else []
PROJECT_CATKIN_DEPENDS = "message_runtime;std_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "wanji_msgs"
PROJECT_SPACE_DIR = "/home/exbot/catkin_ws/install"
PROJECT_VERSION = "1.2.0"
