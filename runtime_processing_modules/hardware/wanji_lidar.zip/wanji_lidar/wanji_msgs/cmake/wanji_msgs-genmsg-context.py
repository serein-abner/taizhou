# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/exbot/catkin_ws/src/wanji-master/wanji_msgs/msg/WanjiPacket.msg;/home/exbot/catkin_ws/src/wanji-master/wanji_msgs/msg/WanjiScan.msg"
services_str = ""
pkg_name = "wanji_msgs"
dependencies_str = "std_msgs"
langs = "gencpp;genlisp;genpy"
dep_include_paths_str = "wanji_msgs;/home/exbot/catkin_ws/src/wanji-master/wanji_msgs/msg;std_msgs;/opt/ros/indigo/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/indigo/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
